package iobasics;

public class driver {

    public static void main(String[] args) {
        Date date = new Date (1,1,1970);
        System.out.println(date);
    }

    

}
